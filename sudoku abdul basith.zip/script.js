// =========================================
// 1. CONFIGURATION & STATE
// =========================================
const CONSTANTS = {
    MISTAKE_LIMIT: 10,
    SCORE_CORRECT: 10,
    SCORE_COMPLETION: 100,
    CLUES_COUNT: 8 // Tantangan Ekstrem (Hanya 8 angka awal)
};

let state = {
    solution: [],       // Kunci jawaban (9x9)
    initialBoard: [],   // Papan awal (untuk tahu mana yang tidak boleh diedit)
    currentBoard: [],   // Papan saat ini (input user)
    notes: [],          // Catatan (9x9 array of arrays)
    history: [],        // Stack untuk Undo
    selected: null,     // Posisi {r, c} yang dipilih
    mistakes: 0,
    score: 0,
    timer: 0,
    timerInterval: null,
    isNoteMode: false,
    isGameOver: false,
    completedCounts: new Array(10).fill(0) // Melacak jumlah angka yang selesai (1-9)
};

// =========================================
// 2. INITIALIZATION
// =========================================
document.addEventListener('DOMContentLoaded', () => {
    initGame();
    setupEventListeners();
});

function initGame() {
    // Reset State
    clearInterval(state.timerInterval);
    state = {
        ...state,
        solution: [],
        initialBoard: [],
        currentBoard: [],
        notes: Array.from({ length: 9 }, () => Array.from({ length: 9 }, () => [])),
        history: [],
        selected: null,
        mistakes: 0,
        score: 0,
        timer: 0,
        isGameOver: false,
        completedCounts: new Array(10).fill(0)
    };

    // Update UI Reset
    updateUI();
    
    // 1. Generate Full Solution
    const baseBoard = Array.from({ length: 9 }, () => Array(9).fill(0));
    fillDiagonal(baseBoard);
    solveSudoku(baseBoard);
    state.solution = JSON.parse(JSON.stringify(baseBoard));

    // 2. Create Puzzle (Remove numbers)
    state.currentBoard = JSON.parse(JSON.stringify(baseBoard));
    removeDigits(state.currentBoard, 81 - CONSTANTS.CLUES_COUNT);
    state.initialBoard = JSON.parse(JSON.stringify(state.currentBoard));

    // 3. Render & Start
    createBoardHTML();
    startTimer();
}

// =========================================
// 3. CORE GAME LOGIC (INPUT)
// =========================================
function handleInput(num) {
    if (state.isGameOver || !state.selected) return;
    const { r, c } = state.selected;

    // Cegah edit angka bawaan (Clue)
    if (state.initialBoard[r][c] !== 0) return;

    const prevVal = state.currentBoard[r][c];
    const prevNotes = [...state.notes[r][c]];

    // --- MODE NOTES ---
    if (state.isNoteMode) {
        if (state.currentBoard[r][c] !== 0) return; // Jangan note di atas angka jadi
        
        let cellNotes = state.notes[r][c];
        if (cellNotes.includes(num)) {
            cellNotes = cellNotes.filter(n => n !== num); // Hapus
        } else {
            cellNotes.push(num); // Tambah
        }
        state.notes[r][c] = cellNotes;
        
        addToHistory({ type: 'note', r, c, prevVal, prevNotes, newVal: 0, newNotes: [...cellNotes] });
        renderTile(r, c);
        return;
    }

    // --- MODE JAWAB ---
    if (prevVal === num) return; // Angka sama, abaikan

    // Cek Jawaban Benar/Salah
    if (num !== state.solution[r][c]) {
        handleMistake(r, c);
    } else {
        // Jawaban Benar
        state.currentBoard[r][c] = num;
        state.notes[r][c] = []; // Hapus notes
        state.score += CONSTANTS.SCORE_CORRECT;
        
        checkCompletionBonus(r, c, num);
        addToHistory({ type: 'input', r, c, prevVal, prevNotes, newVal: num, newNotes: [] });
        
        renderTile(r, c);
        highlightBoard(num); // Highlight angka yang baru diinput
        
        checkWinCondition();
    }
    updateUI();
}

function handleMistake(r, c) {
    state.mistakes++;
    const tile = document.getElementById(`${r}-${c}`);
    
    // Animasi Error (Shake)
    tile.classList.add('error');
    setTimeout(() => tile.classList.remove('error'), 500);

    if (state.mistakes >= CONSTANTS.MISTAKE_LIMIT) {
        endGame(false);
    }
}

function handleErase() {
    if (state.isGameOver || !state.selected) return;
    const { r, c } = state.selected;

    if (state.initialBoard[r][c] !== 0) return; // Jangan hapus clue

    const prevVal = state.currentBoard[r][c];
    const prevNotes = [...state.notes[r][c]];

    if (prevVal === 0 && prevNotes.length === 0) return; // Kosong

    state.currentBoard[r][c] = 0;
    state.notes[r][c] = [];

    addToHistory({ type: 'erase', r, c, prevVal, prevNotes, newVal: 0, newNotes: [] });
    
    renderTile(r, c);
    highlightBoard(state.currentBoard[r][c]); // Re-highlight
}

function handleUndo() {
    if (state.history.length === 0 || state.isGameOver) return;

    const lastAction = state.history.pop();
    const { r, c, prevVal, prevNotes } = lastAction;

    state.currentBoard[r][c] = prevVal;
    state.notes[r][c] = prevNotes;

    renderTile(r, c);
    selectTile(r, c); // Fokus kembali ke tile yang di-undo
}

function addToHistory(action) {
    state.history.push(action);
    if (state.history.length > 50) state.history.shift(); // Batasi history agar memori aman
}

// =========================================
// 4. UI & RENDERING
// =========================================
function createBoardHTML() {
    const boardDiv = document.getElementById('board');
    boardDiv.innerHTML = '';

    for (let r = 0; r < 9; r++) {
        for (let c = 0; c < 9; c++) {
            const tile = document.createElement('div');
            tile.id = `${r}-${c}`;
            tile.classList.add('tile');
            
            // Event Listener Klik
            tile.addEventListener('click', () => selectTile(r, c));
            
            boardDiv.appendChild(tile);
            renderTile(r, c);
        }
    }
}

function renderTile(r, c) {
    const tile = document.getElementById(`${r}-${c}`);
    const val = state.currentBoard[r][c];
    const notes = state.notes[r][c];

    // Reset Class
    tile.className = 'tile';
    
    // Grid styling logic (Border tebal)
    if (c === 2 || c === 5) tile.style.borderRight = "2px solid #334155";
    if ((r === 2 || r === 5)) {
        // Note: Border bawah ditangani CSS Grid logic di style.css, 
        // tapi jika perlu override inline bisa disini. 
        // Kita andalkan style.css agar lebih bersih.
    }

    tile.innerHTML = ''; // Bersihkan isi

    if (val !== 0) {
        tile.textContent = val;
        if (state.initialBoard[r][c] !== 0) {
            tile.classList.add('tile-start');
        } else {
            tile.classList.add('tile-user');
        }
    } else if (notes.length > 0) {
        // Render Notes Grid
        const noteContainer = document.createElement('div');
        noteContainer.className = 'notes-grid';
        for (let i = 1; i <= 9; i++) {
            const noteNum = document.createElement('div');
            noteNum.className = 'note-num';
            if (notes.includes(i)) noteNum.textContent = i;
            noteContainer.appendChild(noteNum);
        }
        tile.appendChild(noteContainer);
    }

    // Re-apply selection state
    if (state.selected && state.selected.r === r && state.selected.c === c) {
        tile.classList.add('selected');
    }
}

function selectTile(r, c) {
    if (state.isGameOver) return;

    // Hapus seleksi lama
    if (state.selected) {
        const prev = document.getElementById(`${state.selected.r}-${state.selected.c}`);
        if (prev) prev.classList.remove('selected');
    }

    state.selected = { r, c };
    const tile = document.getElementById(`${r}-${c}`);
    tile.classList.add('selected');

    // Highlight angka yang sama
    const val = state.currentBoard[r][c];
    highlightBoard(val);
}

function highlightBoard(num) {
    // Hapus highlight lama
    document.querySelectorAll('.highlight-same').forEach(el => el.classList.remove('highlight-same'));

    if (num === 0) return; // Jangan highlight kotak kosong

    for (let r = 0; r < 9; r++) {
        for (let c = 0; c < 9; c++) {
            if (state.currentBoard[r][c] === num) {
                document.getElementById(`${r}-${c}`).classList.add('highlight-same');
            }
        }
    }
}

function updateUI() {
    document.getElementById('score').innerText = state.score;
    document.getElementById('mistakes').innerText = `${state.mistakes}/${CONSTANTS.MISTAKE_LIMIT}`;
    
    const noteBtn = document.getElementById('btn-note');
    const noteStatus = document.getElementById('note-status');
    
    if (state.isNoteMode) {
        noteBtn.classList.add('active');
        noteStatus.innerText = "ON";
    } else {
        noteBtn.classList.remove('active');
        noteStatus.innerText = "OFF";
    }
}

// =========================================
// 5. CONTROLS & EVENTS
// =========================================
function setupEventListeners() {
    // 1. Tombol Tools
    document.getElementById('btn-undo').onclick = handleUndo;
    document.getElementById('btn-erase').onclick = handleErase;
    document.getElementById('btn-note').onclick = () => {
        state.isNoteMode = !state.isNoteMode;
        updateUI();
    };

    // 2. Numpad UI (Klik)
    const numpadDiv = document.querySelector('.numpad');
    numpadDiv.innerHTML = ''; // Bersihkan dulu
    for (let i = 1; i <= 9; i++) {
        const btn = document.createElement('button');
        btn.textContent = i;
        btn.className = 'num-btn';
        btn.onclick = () => handleInput(i);
        numpadDiv.appendChild(btn);
    }

    // 3. Keyboard Support (Panah & Angka)
    document.addEventListener('keydown', (e) => {
        if (state.isGameOver) return;

        // Input Angka
        const num = parseInt(e.key);
        if (!isNaN(num) && num >= 1 && num <= 9) {
            handleInput(num);
            return;
        }

        // Hapus (Backspace/Delete)
        if (e.key === 'Backspace' || e.key === 'Delete') {
            handleErase();
            return;
        }

        // Navigasi Panah
        if (!state.selected) return;
        let { r, c } = state.selected;
        
        if (e.key === 'ArrowUp') r = (r > 0) ? r - 1 : 8;
        if (e.key === 'ArrowDown') r = (r < 8) ? r + 1 : 0;
        if (e.key === 'ArrowLeft') c = (c > 0) ? c - 1 : 8;
        if (e.key === 'ArrowRight') c = (c < 8) ? c + 1 : 0;

        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
            e.preventDefault(); // Mencegah scroll halaman
            selectTile(r, c);
        }
    });
}

// =========================================
// 6. UTILITIES & LOGIC HELPER
// =========================================
function startTimer() {
    state.timerInterval = setInterval(() => {
        state.timer++;
        const m = String(Math.floor(state.timer / 60)).padStart(2, '0');
        const s = String(state.timer % 60).padStart(2, '0');
        document.getElementById('timer').innerText = `${m}:${s}`;
    }, 1000);
}

function checkCompletionBonus(r, c, num) {
    // Cek apakah angka tersebut sudah lengkap 9 buah di papan
    let count = 0;
    for(let i=0; i<9; i++) {
        for(let j=0; j<9; j++) {
            if (state.currentBoard[i][j] === num) count++;
        }
    }

    if (count === 9 && state.completedCounts[num] === 0) {
        state.completedCounts[num] = 1;
        state.score += CONSTANTS.SCORE_COMPLETION;
    }
}

function checkWinCondition() {
    for (let r = 0; r < 9; r++) {
        for (let c = 0; c < 9; c++) {
            if (state.currentBoard[r][c] !== state.solution[r][c]) return;
        }
    }
    endGame(true);
}

function endGame(isWin) {
    state.isGameOver = true;
    clearInterval(state.timerInterval);
    
    if (isWin) {
        alert(`🏆 SELAMAT! Anda menang!\nSkor Akhir: ${state.score}\nWaktu: ${document.getElementById('timer').innerText}`);
    } else {
        alert(`❌ GAME OVER.\nKesempatan habis. Coba lagi!`);
    }
}

// --- SUDOKU GENERATOR ALGORITHMS ---
function fillDiagonal(board) {
    for (let i = 0; i < 9; i += 3) fillBox(board, i, i);
}

function fillBox(board, row, col) {
    let num;
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            do {
                num = Math.floor(Math.random() * 9) + 1;
            } while (!isSafeInBox(board, row, col, num));
            board[row + i][col + j] = num;
        }
    }
}

function isSafeInBox(board, rowStart, colStart, num) {
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (board[rowStart + i][colStart + j] === num) return false;
        }
    }
    return true;
}

function isSafe(board, row, col, num) {
    for (let x = 0; x < 9; x++) {
        if (board[row][x] === num || board[x][col] === num) return false;
    }
    const startRow = row - row % 3;
    const startCol = col - col % 3;
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (board[i + startRow][j + startCol] === num) return false;
        }
    }
    return true;
}

function solveSudoku(board) {
    for (let row = 0; row < 9; row++) {
        for (let col = 0; col < 9; col++) {
            if (board[row][col] === 0) {
                for (let num = 1; num <= 9; num++) {
                    if (isSafe(board, row, col, num)) {
                        board[row][col] = num;
                        if (solveSudoku(board)) return true;
                        board[row][col] = 0;
                    }
                }
                return false;
            }
        }
    }
    return true;
}

function removeDigits(board, count) {
    while (count > 0) {
        const cellId = Math.floor(Math.random() * 81);
        const i = Math.floor(cellId / 9);
        const j = cellId % 9;
        if (board[i][j] !== 0) {
            board[i][j] = 0;
            count--;
        }
    }
}